package com.ieum.domain;



public enum UserStatus {
    ACTIVE, INACTIVE;
}

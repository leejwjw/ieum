package com.ieum.domain;

public enum RoomType {
    PRIVATE,
    OPEN
}